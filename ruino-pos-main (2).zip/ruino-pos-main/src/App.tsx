import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { OfflineIndicator } from "@/components/OfflineIndicator";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import LoginPage from "./pages/Login";
import DashboardPage from "./pages/Dashboard";
import POSPage from "./pages/POS";
import InventoryPage from "./pages/Inventory";
import SalesPage from "./pages/Sales";
import CreditsPage from "./pages/Credits";
import CashBoxPage from "./pages/CashBox";
import SettingsPage from "./pages/Settings";
import ReportsPage from "./pages/Reports";
import ProfilePage from "./pages/Profile";
import CustomersPage from "./pages/Customers";
import CustomerProfilePage from "./pages/CustomerProfile";
import SuppliersPage from "./pages/Suppliers";
import SupplierProfilePage from "./pages/SupplierProfile";
import DailyReportFullPage from "./pages/DailyReportFull";
import MonthlyReportPage from "./pages/MonthlyReport";
import InvoicesPage from "./pages/Invoices";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <OfflineIndicator />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Navigate to="/pos" replace />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/dashboard" element={<ProtectedRoute requireAdmin><DashboardPage /></ProtectedRoute>} />
            <Route path="/pos" element={<ProtectedRoute><POSPage /></ProtectedRoute>} />
            <Route path="/inventory" element={<ProtectedRoute><InventoryPage /></ProtectedRoute>} />
            <Route path="/sales" element={<ProtectedRoute><SalesPage /></ProtectedRoute>} />
            <Route path="/credits" element={<ProtectedRoute><CreditsPage /></ProtectedRoute>} />
            <Route path="/cashbox" element={<ProtectedRoute requireAdmin><CashBoxPage /></ProtectedRoute>} />
            <Route path="/customers" element={<ProtectedRoute><CustomersPage /></ProtectedRoute>} />
            <Route path="/customers/:id" element={<ProtectedRoute><CustomerProfilePage /></ProtectedRoute>} />
            <Route path="/suppliers" element={<ProtectedRoute requireAdmin><SuppliersPage /></ProtectedRoute>} />
            <Route path="/suppliers/:id" element={<ProtectedRoute requireAdmin><SupplierProfilePage /></ProtectedRoute>} />
            <Route path="/invoices" element={<ProtectedRoute requireAdmin><InvoicesPage /></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute requireAdmin><SettingsPage /></ProtectedRoute>} />
            <Route path="/reports" element={<ProtectedRoute requireAdmin><ReportsPage /></ProtectedRoute>} />
            <Route path="/reports/full" element={<ProtectedRoute requireAdmin><DailyReportFullPage /></ProtectedRoute>} />
            <Route path="/reports/monthly" element={<ProtectedRoute requireAdmin><MonthlyReportPage /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
